x = input("Enter your precision")

print('%1.%xf' % (22.0/7))

